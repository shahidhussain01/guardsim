package com.guardsim.callscreen.ui

import android.animation.ValueAnimator
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.guardsim.callscreen.CallScreeningRoleHelper
import com.guardsim.callscreen.R
import com.guardsim.callscreen.data.CallHistoryDbHelper
import java.util.Calendar

class HomeFragment : Fragment(R.layout.fragment_home) {

    private val roleRequestLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshStatus()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val statusText = view.findViewById<TextView>(R.id.statusText)
        val enableButton = view.findViewById<Button>(R.id.enableButton)
        val todayCount = view.findViewById<TextView>(R.id.todayCount)
        val totalCount = view.findViewById<TextView>(R.id.totalCount)

        enableButton.setOnClickListener {
            val context = requireContext()
            if (!CallScreeningRoleHelper.isAvailable(context)) {
                statusText.text = getString(R.string.role_unavailable)
                return@setOnClickListener
            }
            if (CallScreeningRoleHelper.isEnabled(context)) {
                return@setOnClickListener
            }
            CallScreeningRoleHelper.buildRequestIntent(context)?.let {
                roleRequestLauncher.launch(it)
            }
        }

        val dbHelper = CallHistoryDbHelper(requireContext())
        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        animateCount(todayCount, dbHelper.getCountSince(startOfToday))
        animateCount(totalCount, dbHelper.getTotalCount())

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onPause() {
        super.onPause()
        view?.findViewById<ImageView>(R.id.shieldIcon)?.animate()?.cancel()
    }

    private fun refreshStatus() {
        val view = view ?: return
        val statusText = view.findViewById<TextView>(R.id.statusText)
        val enableButton = view.findViewById<Button>(R.id.enableButton)
        val shieldIcon = view.findViewById<ImageView>(R.id.shieldIcon)

        val enabled = CallScreeningRoleHelper.isEnabled(requireContext())
        if (enabled) {
            statusText.text = getString(R.string.protection_on)
            enableButton.text = getString(R.string.protection_enabled_button)
            pulseShield(shieldIcon)
        } else {
            statusText.text = getString(R.string.protection_off)
            enableButton.text = getString(R.string.enable_button)
            shieldIcon.animate().cancel()
            shieldIcon.scaleX = 1f
            shieldIcon.scaleY = 1f
        }
    }

    private fun pulseShield(shieldIcon: ImageView) {
        if (!isAdded) return
        shieldIcon.animate()
            .scaleX(1.1f).scaleY(1.1f)
            .setDuration(700)
            .withEndAction {
                if (!isAdded) return@withEndAction
                shieldIcon.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(700)
                    .withEndAction { pulseShield(shieldIcon) }
                    .start()
            }
            .start()
    }

    private fun animateCount(textView: TextView, target: Int) {
        val animator = ValueAnimator.ofInt(0, target)
        animator.duration = 800
        animator.addUpdateListener {
            textView.text = (it.animatedValue as Int).toString()
        }
        animator.start()
    }
}
