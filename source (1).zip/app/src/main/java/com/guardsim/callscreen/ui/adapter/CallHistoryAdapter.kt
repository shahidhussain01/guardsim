package com.guardsim.callscreen.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.guardsim.callscreen.R
import com.guardsim.callscreen.data.CallEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CallHistoryAdapter(private val items: List<CallEvent>) :
    RecyclerView.Adapter<CallHistoryAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val numberText: TextView = view.findViewById(R.id.eventNumber)
        val timeText: TextView = view.findViewById(R.id.eventTime)
        val actionText: TextView = view.findViewById(R.id.eventAction)
        val dot: ImageView = view.findViewById(R.id.eventDot)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_call_history, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val event = items[position]
        holder.numberText.text = event.number
        val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        holder.timeText.text = sdf.format(Date(event.timestamp))

        val context = holder.itemView.context
        if (event.action == "BLOCKED") {
            holder.actionText.text = context.getString(R.string.action_blocked)
            holder.dot.setColorFilter(ContextCompat.getColor(context, R.color.guard_danger))
        } else {
            holder.actionText.text = context.getString(R.string.action_silenced)
            holder.dot.setColorFilter(ContextCompat.getColor(context, R.color.guard_warning))
        }
    }

    override fun getItemCount(): Int = items.size
}
