package com.guardsim.callscreen.ui

import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.guardsim.callscreen.R
import com.guardsim.callscreen.data.CallHistoryDbHelper
import com.guardsim.callscreen.ui.adapter.CallHistoryAdapter

class HistoryFragment : Fragment(R.layout.fragment_history) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView = view.findViewById<RecyclerView>(R.id.historyList)
        val emptyText = view.findViewById<TextView>(R.id.emptyText)

        val dbHelper = CallHistoryDbHelper(requireContext())
        val events = dbHelper.getRecentEvents(200)

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = CallHistoryAdapter(events)

        val animation = AnimationUtils.loadLayoutAnimation(
            requireContext(), R.anim.layout_animation_fall_down
        )
        recyclerView.layoutAnimation = animation
        recyclerView.scheduleLayoutAnimation()

        emptyText.visibility = if (events.isEmpty()) View.VISIBLE else View.GONE
    }
}
