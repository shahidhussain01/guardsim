package com.guardsim.callscreen.data

import android.content.Context

object SettingsStore {
    private const val PREFS_NAME = "guardsim_settings"
    private const val KEY_AUTO_SMS_ENABLED = "auto_sms_enabled"
    private const val KEY_AUTO_SMS_MESSAGE = "auto_sms_message"

    private const val DEFAULT_MESSAGE =
        "I can't take calls right now. Please text me what this is about."

    fun isAutoSmsEnabled(context: Context): Boolean {
        return prefs(context).getBoolean(KEY_AUTO_SMS_ENABLED, false)
    }

    fun setAutoSmsEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_SMS_ENABLED, enabled).apply()
    }

    fun getAutoSmsMessage(context: Context): String {
        return prefs(context).getString(KEY_AUTO_SMS_MESSAGE, DEFAULT_MESSAGE) ?: DEFAULT_MESSAGE
    }

    fun setAutoSmsMessage(context: Context, message: String) {
        prefs(context).edit().putString(KEY_AUTO_SMS_MESSAGE, message).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
