package com.guardsim.callscreen.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.guardsim.callscreen.BlocklistStore
import com.guardsim.callscreen.PaywallActivity
import com.guardsim.callscreen.R
import com.guardsim.callscreen.data.SettingsStore

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private val contactsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val smsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            SettingsStore.setAutoSmsEnabled(requireContext(), false)
            view?.findViewById<Switch>(R.id.autoSmsSwitch)?.isChecked = false
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val silenceSwitch = view.findViewById<Switch>(R.id.silenceUnknownSwitch)
        val autoSmsSwitch = view.findViewById<Switch>(R.id.autoSmsSwitch)
        val autoSmsMessage = view.findViewById<EditText>(R.id.autoSmsMessage)
        val upgradeButton = view.findViewById<Button>(R.id.upgradeButton)

        val context = requireContext()

        silenceSwitch.isChecked = BlocklistStore.isSilenceUnknownEnabled(context)
        silenceSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked && ContextCompat.checkSelfPermission(
                    context, Manifest.permission.READ_CONTACTS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
            }
            BlocklistStore.setSilenceUnknown(context, isChecked)
        }

        autoSmsMessage.setText(SettingsStore.getAutoSmsMessage(context))
        autoSmsSwitch.isChecked = SettingsStore.isAutoSmsEnabled(context)
        autoSmsMessage.isEnabled = autoSmsSwitch.isChecked

        autoSmsSwitch.setOnCheckedChangeListener { _, isChecked ->
            autoSmsMessage.isEnabled = isChecked
            if (isChecked && ContextCompat.checkSelfPermission(
                    context, Manifest.permission.SEND_SMS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
            SettingsStore.setAutoSmsEnabled(context, isChecked)
        }

        autoSmsMessage.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                SettingsStore.setAutoSmsMessage(context, autoSmsMessage.text.toString())
            }
        }

        upgradeButton.setOnClickListener {
            startActivity(Intent(context, PaywallActivity::class.java))
        }
    }
}
