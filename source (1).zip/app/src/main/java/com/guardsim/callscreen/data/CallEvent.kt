package com.guardsim.callscreen.data

data class CallEvent(
    val id: Long = 0,
    val number: String,
    val timestamp: Long,
    val action: String // "BLOCKED" or "SILENCED"
)
