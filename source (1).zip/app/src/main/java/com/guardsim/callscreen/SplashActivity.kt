package com.guardsim.callscreen

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val shield = findViewById<ImageView>(R.id.splashShield)
        val text = findViewById<TextView>(R.id.splashText)

        val scaleX = ObjectAnimator.ofFloat(shield, "scaleX", 0.5f, 1f)
        val scaleY = ObjectAnimator.ofFloat(shield, "scaleY", 0.5f, 1f)
        val fadeIn = ObjectAnimator.ofFloat(shield, "alpha", 0f, 1f)

        val shieldSet = AnimatorSet()
        shieldSet.playTogether(scaleX, scaleY, fadeIn)
        shieldSet.duration = 600
        shieldSet.interpolator = OvershootInterpolator()
        shieldSet.start()

        val textFade = ObjectAnimator.ofFloat(text, "alpha", 0f, 1f)
        textFade.startDelay = 250
        textFade.duration = 500
        textFade.start()

        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }, 1400)
    }
}
