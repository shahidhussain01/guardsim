package com.guardsim.callscreen.ui

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.guardsim.callscreen.BlocklistStore
import com.guardsim.callscreen.R
import com.guardsim.callscreen.ui.adapter.BlocklistAdapter

class BlocklistFragment : Fragment(R.layout.fragment_blocklist) {

    private lateinit var adapter: BlocklistAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val numberInput = view.findViewById<EditText>(R.id.numberInput)
        val addButton = view.findViewById<Button>(R.id.addButton)
        val recyclerView = view.findViewById<RecyclerView>(R.id.blocklistRecycler)

        val numbers = BlocklistStore.getBlockedNumbers(requireContext()).toMutableList()
        adapter = BlocklistAdapter(numbers) { number ->
            BlocklistStore.removeBlockedNumber(requireContext(), number)
        }
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        addButton.setOnClickListener {
            val raw = numberInput.text.toString().trim()
            if (raw.isNotEmpty()) {
                val normalized = BlocklistStore.normalize(raw)
                BlocklistStore.addBlockedNumber(requireContext(), normalized)
                adapter.addNumber(normalized)
                numberInput.text.clear()
            }
        }
    }
}
