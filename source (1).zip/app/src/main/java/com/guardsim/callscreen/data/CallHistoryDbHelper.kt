package com.guardsim.callscreen.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class CallHistoryDbHelper(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "guardsim_history.db"
        private const val DB_VERSION = 1
        private const val TABLE = "call_events"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE $TABLE (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "number TEXT NOT NULL, " +
                "timestamp INTEGER NOT NULL, " +
                "action TEXT NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    fun insertEvent(event: CallEvent) {
        val values = ContentValues().apply {
            put("number", event.number)
            put("timestamp", event.timestamp)
            put("action", event.action)
        }
        writableDatabase.insert(TABLE, null, values)
    }

    fun getRecentEvents(limit: Int = 100): List<CallEvent> {
        val results = mutableListOf<CallEvent>()
        val cursor = readableDatabase.query(
            TABLE, null, null, null, null, null,
            "timestamp DESC", limit.toString()
        )
        cursor.use {
            val idIndex = it.getColumnIndexOrThrow("id")
            val numberIndex = it.getColumnIndexOrThrow("number")
            val timeIndex = it.getColumnIndexOrThrow("timestamp")
            val actionIndex = it.getColumnIndexOrThrow("action")
            while (it.moveToNext()) {
                results.add(
                    CallEvent(
                        id = it.getLong(idIndex),
                        number = it.getString(numberIndex),
                        timestamp = it.getLong(timeIndex),
                        action = it.getString(actionIndex)
                    )
                )
            }
        }
        return results
    }

    fun getCountSince(sinceMillis: Long): Int {
        val cursor = readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM $TABLE WHERE timestamp >= ?",
            arrayOf(sinceMillis.toString())
        )
        cursor.use {
            if (it.moveToFirst()) {
                return it.getInt(0)
            }
        }
        return 0
    }

    fun getTotalCount(): Int {
        val cursor = readableDatabase.rawQuery("SELECT COUNT(*) FROM $TABLE", null)
        cursor.use {
            if (it.moveToFirst()) {
                return it.getInt(0)
            }
        }
        return 0
    }
}
