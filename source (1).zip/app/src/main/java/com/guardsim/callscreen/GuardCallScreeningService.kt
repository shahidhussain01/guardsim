package com.guardsim.callscreen

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.CallScreeningService.CallResponse
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.guardsim.callscreen.data.CallEvent
import com.guardsim.callscreen.data.CallHistoryDbHelper
import com.guardsim.callscreen.data.SettingsStore

/**
 * This is the heart of GuardSim. Android calls onScreenCall() for every
 * incoming call BEFORE the phone rings, because this app holds the
 * ROLE_CALL_SCREENING system role. We decide here whether to let it
 * ring normally, reject it outright, or let it ring silently -- and we
 * log every block/silence event and can auto-reply by SMS.
 */
class GuardCallScreeningService : CallScreeningService() {

    private val dbHelper by lazy { CallHistoryDbHelper(this) }

    override fun onScreenCall(callDetails: Call.Details) {
        val rawNumber = callDetails.handle?.schemeSpecificPart

        if (rawNumber == null) {
            allowCall(callDetails)
            return
        }

        val number = BlocklistStore.normalize(rawNumber)

        if (BlocklistStore.isBlocked(this, number)) {
            logEvent(number, "BLOCKED")
            maybeSendAutoSms(number)
            respondToCall(
                callDetails,
                CallResponse.Builder()
                    .setDisallowCall(true)
                    .setRejectCall(true)
                    .setSkipNotification(true)
                    .build()
            )
            return
        }

        if (BlocklistStore.isSilenceUnknownEnabled(this) && !isInContacts(number)) {
            logEvent(number, "SILENCED")
            respondToCall(
                callDetails,
                CallResponse.Builder()
                    .setSilenceCall(true)
                    .build()
            )
            return
        }

        allowCall(callDetails)
    }

    private fun allowCall(callDetails: Call.Details) {
        respondToCall(callDetails, CallResponse.Builder().build())
    }

    private fun logEvent(number: String, action: String) {
        try {
            dbHelper.insertEvent(
                CallEvent(number = number, timestamp = System.currentTimeMillis(), action = action)
            )
        } catch (e: Exception) {
            // Never let a logging failure crash call screening
        }
    }

    private fun maybeSendAutoSms(number: String) {
        if (!SettingsStore.isAutoSmsEnabled(this)) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        try {
            val message = SettingsStore.getAutoSmsMessage(this)
            val smsManager = getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
            smsManager.sendTextMessage(number, null, message, null, null)
        } catch (e: Exception) {
            // Don't let a failed SMS crash call screening
        }
    }

    private fun isInContacts(number: String): Boolean {
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number)
            )
            contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup._ID),
                null, null, null
            )?.use { it.moveToFirst() } ?: false
        } catch (e: SecurityException) {
            true
        }
    }
}
