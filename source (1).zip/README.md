# GuardSim (Full App)

A four-tab Android call-screening app:

- **Home** — protection toggle with a pulsing shield animation, live
  animated counters (blocked today / total protected)
- **History** — every blocked/silenced call, logged to a local database,
  with a fall-in entrance animation
- **Blocklist** — add/remove numbers, animated list
- **Settings** — silence-unknown-callers toggle, auto-SMS-reply to
  blocked callers (with an editable message), and a link to the
  Personal Pro / Business plan screen (not yet purchasable — that
  needs Play Billing, set up after the Play Store listing goes live)

Everything is fully offline and free to run. No AI phone-answering
feature is included, on purpose: Android does not allow third-party
apps to join live call audio, so that specific feature (like Google's
Pixel Call Screen) is not something any app outside Google's own
system dialer can legally do.

## Updating your existing GitHub repo

You've already got the repo set up with the build workflow in place.
To update to this version, you only need to replace ONE file:

1. Go to your `guardsim` repo on GitHub.
2. Click **Add file > Upload files**.
3. Drag in this **source.zip** (just the one file — don't unzip it).
4. Commit. Since the filename matches, it replaces the old one.
5. Go to the **Actions** tab — it rebuilds automatically.
6. Download the new APK from the finished run's Artifacts section,
   same as before.
